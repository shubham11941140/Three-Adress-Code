/* Simple while loop testing */
int main () {

   int a = 100;
   int b = 200;
   int c = a+b;
   while (a<b && b<c) {
	a=a+1;
	b=b+a;
   } 
}
 