int main()
{
    int x, y;
    if (x>y)
    {
	x=x+2;
    }
    if (x<y)
    {
	y=y+x;	     
    }
    if (x==y)
    {
	x=0;
	y=0;
    }
}