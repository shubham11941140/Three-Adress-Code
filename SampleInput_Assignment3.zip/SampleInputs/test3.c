//Simple for loop 
#include <stdio.h>
int main()
{
     int a;
     int b;
     b=100;
     a=200;
     if(b>a) {
     	int a = 5;
	b=b+a;
    }
    else{
	b=b+a;
    }
}