//Simple program to test special functions.

int main(void)
{
    int a, b, c;
     float d, e, f;
    a=10;
    b=20;
     c=30;
     f=2.3;
     d = c+f;
     e=f+f;
}